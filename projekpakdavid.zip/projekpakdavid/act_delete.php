<?php 
// menghubungkan koneksi ke database
$koneksi = mysqli_connect('localhost','root','','mfs20_db');
$id = $_GET ['id'];

// query delete
$query = "DELETE FROM tbl_siswa WHERE id='$id'";
$hasil = mysqli_query($koneksi, $query);

if ($hasil) {
    echo "<script>
        alert('Hapus data berhasil!');
        window.location='read.php';
    </script>";
} else {
    echo "<script>
        alert('Hapus data gagal');
        window.location='read.php';
    </script>";
}