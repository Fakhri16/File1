<?php
// menghubungkan koneksi ke database
$koneksi = mysqli_connect('localhost','root','','mfs20_db');

$id = $_POST['id'];
$nama = $_POST['nama'];
$absen = $_POST['absen'];
$telepon = $_POST['telepon'];
$kelas = $_POST['kelas'];
$jurusan = $_POST['jurusan'];

// validasi serial
$query = "SELECT nama FROM tbl_siswa WHERE nama='$nama' AND id <> '$id'";
$ada = mysqli_query($koneksi, $query);

if (mysqli_num_rows($ada) > 0) {
    echo "<script>
            alert('Nama sudah terdaftar');
            history.go(-1);
          </script>";
} else {
    $query = "UPDATE tbl_siswa SET nama='$nama', absen='$absen', telepon='$telepon', kelas='$kelas', jurusan='$jurusan' WHERE id='$id'";
    mysqli_query($koneksi, $query);
    echo "<script>
            alert('Ubah data berhasil!');
            window.location='read.php';
          </script>";
}
?>
