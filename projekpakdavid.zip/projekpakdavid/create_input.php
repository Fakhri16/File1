<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="proses.php" method="post">
    <label for="kelas">Nama :</label>
    <input type="text" name="nama">
    <br><br>
    <label for="absen">Absen :</label>
    <input type="text" name="absen">
    <br><br>
    <label for="telepon">telepon</label>
    <input type="text" name="telepon">
    <br><br>
    <label for="kelas">Kelas :</label>
    <select name="kelas" id="kelas">
        <option value="0">_</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="12">12</option>
    </select>
    <br><br>
    <label>jurusan :</label>
        <input type="radio" name="jurusan" value="tkj"> tkj 
        <input type="radio" name="jurusan" value="mm"> mm
        <input type="radio" name="jurusan" value="rpl"> rpl
        <input type="radio" name="jurusan" value="otkp"> otkp
        <input type="radio" name="jurusan" value="bdp"> bdp
        <br><br>
        <button type="submit">Simpan</button>
        </form>
</body>
</html>