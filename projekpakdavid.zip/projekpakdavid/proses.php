<?php
$koneksi = mysqli_connect('localhost', 'root', '', 'mfs20_db');

$nama = $_POST['nama'];

// validasi serial
$query = "SELECT nama FROM tbl_siswa WHERE nama='$nama'";
$ada = mysqli_query($koneksi, $query);

if (mysqli_num_rows($ada) > 0) {
    echo "<script>
        alert('Error! Nama Sudah terdaftar');
        history.go(-1);
        </script>";
} else {
    // Lanjutkan dengan proses INSERT ke database
    $absen = $_POST['absen'];
    $kelas = $_POST['kelas'];
    $telepon = $_POST['telepon'];
    $jurusan = $_POST['jurusan'];

    $query = "INSERT INTO tbl_siswa(nama, absen, kelas,telepon, jurusan) 
                VALUES ('$nama', '$absen', '$kelas','$telepon', '$jurusan')";

    mysqli_query($koneksi, $query);
    echo "<script>
        alert('Simpan Data Berhasil!');
        window.location='read.php';
    </script>"; 
}
