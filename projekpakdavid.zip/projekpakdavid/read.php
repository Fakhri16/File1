<?php
// koneksi
$koneksi = mysqli_connect('localhost', 'root', '', 'mfs20_db');
$query = "SELECT * FROM tbl_siswa";

// menampilkan data
$hasil = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="1pxsolide">
        <thead >
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Absen</th>
                <th>telepon</th>
                <th>kelas</th>
                <th>jurusan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            while ($data = mysqli_fetch_array($hasil)) {
            ?>
                <tr>
                    <td>
                        <?= $no; ?>
                    </td>
                    <td>
                        <?php echo $data['nama']; ?>
                    </td>
                    <td>
                        <?php echo $data['absen']; ?>
                    </td>
                    <td>
                        <?php echo $data['telepon']; ?>
                    </td>
                    <td>
                        <?php echo $data['kelas']; ?>
                    </td>
                    <td>
                        <?php echo $data['jurusan']; ?>
                    </td>
                    <td>
                        <a href="update.php?id=<?= $data['id'] ?>">Edit</a>
                        <a href="act_delete.php?id=<?= $data['id'] ?>">Hapus</a>
                        <a href="create_input.php">back to create</a>
                    </td>
                </tr>
                <?php
                $no++;
            }
            ?>
        </tbody>
    </table>
</body>
</html>
