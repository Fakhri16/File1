<?php
$koneksi = mysqli_connect('localhost','root','','mfs20_db');

$id = $_GET['id'];
$query = "SELECT * FROM tbl_siswa WHERE id='$id'";
$hasil = mysqli_query($koneksi, $query);
$data1 = mysqli_fetch_array($hasil);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!-- Update form -->
<form action="act_update.php" method="post">
    <!-- Existing data from the database -->
    <input type="hidden" name="id" value="<?= $data1['id']; ?>">
    <label for="nama">Nama :</label>
    <input type="text" name="nama" value="<?= $data1['nama']; ?>" >
    <br><br>
    <label for="absen">Absen :</label>
    <input type="text" name="absen" value="<?= $data1['absen']; ?>">
    <br><br>
    <label for="telepon">Telepon :</label>
    <input type="text" name="telepon" value="<?= $data1['telepon']; ?>">
    <br><br>
    <label for="kelas">Kelas :</label>
    <select name="kelas" id="kelas">
        <option value="0" <?= ($data1['kelas'] == 0) ? 'selected' : ''; ?>>_</option>
        <option value="10" <?= ($data1['kelas'] == 10) ? 'selected' : ''; ?>>10</option>
        <option value="11" <?= ($data1['kelas'] == 11) ? 'selected' : ''; ?>>11</option>
        <option value="12" <?= ($data1['kelas'] == 12) ? 'selected' : ''; ?>>12</option>
    </select>
    <br><br>
    <label>Jurusan :</label>
    <input type="radio" name="jurusan" value="tkj" <?= ($data1['jurusan'] == 'tkj') ? 'checked' : ''; ?>> TKJ 
    <input type="radio" name="jurusan" value="mm" <?= ($data1['jurusan'] == 'mm') ? 'checked' : ''; ?>> MM
    <input type="radio" name="jurusan" value="rpl" <?= ($data1['jurusan'] == 'rpl') ? 'checked' : ''; ?>> RPL
    <input type="radio" name="jurusan" value="otkp" <?= ($data1['jurusan'] == 'otkp') ? 'checked' : ''; ?>> OTKP
    <input type="radio" name="jurusan" value="bdp" <?= ($data1['jurusan'] == 'bdp') ? 'checked' : ''; ?>> BDP
    <br><br>
    <button type="submit">Simpan</button>
</form>

</body>
</html>